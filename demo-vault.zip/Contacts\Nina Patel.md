---
role: Security Engineer
company: Acme Corp
email: nina@example.com
phone: "+1 555-0106"
department: Engineering
---
