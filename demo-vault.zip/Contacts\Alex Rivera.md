---
role: DevOps Engineer
company: Acme Corp
email: alex@example.com
phone: "+1 555-0103"
department: Engineering
website: https://alexrivera.dev
---
