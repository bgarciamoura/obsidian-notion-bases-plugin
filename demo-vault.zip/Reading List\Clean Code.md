---
author: Robert C. Martin
genre: Technical
status: Finished
rating: 4.0
year: 2008
pages: 464
cover: Attachments/books/clean-code.jpg
---
