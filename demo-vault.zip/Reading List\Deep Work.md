---
author: Cal Newport
genre: Self-help
status: Reading
rating: 4.2
year: 2016
pages: 296
cover: Attachments/books/deep-work.jpg
---
