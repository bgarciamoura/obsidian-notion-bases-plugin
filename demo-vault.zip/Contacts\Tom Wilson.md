---
role: Product Manager
company: Acme Corp
email: tom@example.com
phone: "+1 555-0107"
department: Management
---
