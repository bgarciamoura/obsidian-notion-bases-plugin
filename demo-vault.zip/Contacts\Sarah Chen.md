---
role: Lead Designer
company: Acme Corp
email: sarah@example.com
phone: "+1 555-0101"
department: Design
website: https://sarahchen.design
---
