---
---

# Notion Bases — Demo Vault

Welcome! This vault demonstrates the main features of the **Notion Bases** plugin.

## Databases in this vault

| Folder | What it showcases |
|--------|-------------------|
| **Projects/** | 6 views (Table, Board, Gallery, List, Calendar, Timeline), 12+ column types, formulas, aggregation, filters, sorts |
| **Contacts/** | Relation columns, lookups, image columns |
| **Tasks/** | Subfolder toggle, folder column, nested task organization |
| **Reading List/** | Gallery view with covers, select filters, card sizes |

## Quick start

1. Open any `_database` file from the sidebar to see the database view
2. Switch between views using the tabs at the top (Table, Board, Calendar...)
3. Click the **folder+** button in the toolbar to include notes from subfolders
4. Try dragging cards in the Board view, or resizing bars in the Timeline view
5. Use the Fields button to show/hide columns, and the filter icon to add filters

## Embed example

You can embed any database inside a note using a code block:

```notion-bases
path: Projects
```

## Links

- [GitHub](https://github.com/bgarciamoura/obsidian-notion-bases-plugin)
- [Buy Me a Coffee](https://buymeacoffee.com/bgarciamoura)
