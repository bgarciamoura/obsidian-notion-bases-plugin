---
status: In progress
priority: High
owner: James Park
start_date: 2026-01-15
due_date: 2026-05-30
budget: 80000
progress: 40
tags:
  - mobile
  - backend
website: https://app.example.com
contact_email: james@example.com
done: false
cover: Attachments/projects/mobile-app.jpg
---

# Mobile App v2

Second major version of the mobile application with offline support and push notifications.
