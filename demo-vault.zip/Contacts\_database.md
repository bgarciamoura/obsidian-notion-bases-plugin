---
notion-bases: true
schema:
  - id: role
    name: Role
    type: text
    visible: true
    width: 160
  - id: company
    name: Company
    type: text
    visible: true
    width: 140
  - id: email
    name: Email
    type: email
    visible: true
    width: 200
  - id: phone
    name: Phone
    type: phone
    visible: true
    width: 150
  - id: department
    name: Department
    type: select
    visible: true
    width: 140
    options:
      - value: Engineering
        color: '#4ea6f5'
      - value: Design
        color: '#c76ced'
      - value: Marketing
        color: '#4bb563'
      - value: Management
        color: '#e8a138'
  - id: website
    name: Website
    type: url
    visible: true
    width: 180
views:
  - id: default
    type: table
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
  - id: board-dept
    name: By department
    type: board
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    groupByColumnId: department
---
