---
status: Doing
priority: Normal
due_date: 2026-03-20
assignee: Tom Wilson
---

# Weekly standup notes

Prepare and send standup summary every Friday.
