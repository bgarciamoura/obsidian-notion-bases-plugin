---
status: In progress
priority: Medium
owner: Maria Lopez
start_date: 2026-04-01
due_date: 2026-06-15
budget: 20000
progress: 15
tags:
  - design
  - frontend
done: false
---

# Design System v2

Major update to the component library with dark mode support and accessibility improvements.
