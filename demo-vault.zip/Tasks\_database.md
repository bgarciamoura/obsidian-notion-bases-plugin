---
notion-bases: true
schema:
  - id: status
    name: Status
    type: status
    visible: true
    width: 130
    options:
      - value: To do
        color: '#868686'
      - value: Doing
        color: '#4ea6f5'
      - value: Done
        color: '#4bb563'
  - id: priority
    name: Priority
    type: select
    visible: true
    width: 110
    options:
      - value: Urgent
        color: '#e25555'
      - value: Normal
        color: '#4ea6f5'
      - value: Low
        color: '#868686'
  - id: due_date
    name: Due date
    type: date
    visible: true
    width: 120
  - id: assignee
    name: Assignee
    type: text
    visible: true
    width: 130
views:
  - id: default
    type: table
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
  - id: board-status
    name: Board
    type: board
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    groupByColumnId: status
---
