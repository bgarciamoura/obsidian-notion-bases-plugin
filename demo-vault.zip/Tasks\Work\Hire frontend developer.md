---
status: Doing
priority: Urgent
due_date: 2026-04-15
assignee: Tom Wilson
---

# Hire frontend developer

Screen candidates, conduct interviews, and extend offer for the open frontend position.
