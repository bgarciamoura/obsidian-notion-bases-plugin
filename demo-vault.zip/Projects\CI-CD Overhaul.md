---
status: Cancelled
priority: Medium
owner: Alex Rivera
start_date: 2026-01-01
due_date: 2026-03-01
budget: 15000
progress: 20
tags:
  - devops
contact_email: alex@example.com
done: false
cover: Attachments/projects/ci-cd.jpg
---

# CI/CD Overhaul

Migrate from Jenkins to GitHub Actions. Cancelled — merged into DevOps Platform project instead.
