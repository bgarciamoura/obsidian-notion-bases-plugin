---
role: UX Researcher
company: Acme Corp
email: maria@example.com
phone: "+1 555-0104"
department: Design
---
