---
author: Walter Isaacson
genre: Biography
status: Want to read
year: 2011
pages: 656
cover: Attachments/books/steve-jobs.jpg
---
