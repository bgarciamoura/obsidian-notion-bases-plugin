---
author: Martin Kleppmann
genre: Technical
status: Reading
rating: 4.8
year: 2017
pages: 616
cover: Attachments/books/data-intensive.jpg
---
