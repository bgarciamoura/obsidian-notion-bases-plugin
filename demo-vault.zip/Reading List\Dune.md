---
author: Frank Herbert
genre: Fiction
status: Want to read
year: 1965
pages: 688
cover: Attachments/books/dune.jpg
---
