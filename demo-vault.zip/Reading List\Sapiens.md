---
author: Yuval Noah Harari
genre: Non-fiction
status: Finished
rating: 4.3
year: 2014
pages: 498
cover: Attachments/books/sapiens.jpg
---
