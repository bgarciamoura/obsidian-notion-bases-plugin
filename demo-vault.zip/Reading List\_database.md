---
notion-bases: true
schema:
  - id: author
    name: Author
    type: text
    visible: true
    width: 160
  - id: genre
    name: Genre
    type: select
    visible: true
    width: 130
    options:
      - value: Fiction
        color: '#c76ced'
      - value: Non-fiction
        color: '#4ea6f5'
      - value: Technical
        color: '#4bb563'
      - value: Self-help
        color: '#e8a138'
      - value: Biography
        color: '#e25555'
  - id: status
    name: Status
    type: select
    visible: true
    width: 120
    options:
      - value: Want to read
        color: '#868686'
      - value: Reading
        color: '#4ea6f5'
      - value: Finished
        color: '#4bb563'
  - id: rating
    name: Rating
    type: number
    visible: true
    width: 100
    numberFormat:
      decimals: 1
      suffix: ' / 5'
  - id: year
    name: Year
    type: number
    visible: true
    width: 80
  - id: pages
    name: Pages
    type: number
    visible: true
    width: 80
  - id: cover
    name: Cover
    type: image
    visible: true
    width: 120
    imageSourceFolder: Attachments/books
views:
  - id: default
    type: table
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
  - id: gallery-view
    name: Gallery
    type: gallery
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    galleryCardSize: medium
    galleryCoverField: cover
  - id: board-status
    name: By status
    type: board
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    groupByColumnId: status
---
