---
status: Doing
priority: Urgent
due_date: 2026-03-31
assignee: Lisa Zhang
---

# Prepare quarterly report

Compile Q1 metrics, revenue data, and team highlights for board presentation.
