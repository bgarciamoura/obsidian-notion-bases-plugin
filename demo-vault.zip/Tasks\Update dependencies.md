---
status: To do
priority: Normal
due_date: 2026-03-25
assignee: Alex Rivera
---

# Update dependencies

Audit and update all npm packages to latest stable versions.
