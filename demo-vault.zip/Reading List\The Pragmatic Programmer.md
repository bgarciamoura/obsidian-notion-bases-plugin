---
author: David Thomas & Andrew Hunt
genre: Technical
status: Finished
rating: 4.6
year: 2019
pages: 352
cover: Attachments/books/pragmatic-programmer.jpg
---
