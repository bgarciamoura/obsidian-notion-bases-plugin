---
status: Done
priority: Medium
owner: Maria Lopez
start_date: 2025-11-01
due_date: 2026-01-31
budget: 12000
progress: 100
tags:
  - design
website: https://brand.example.com
contact_email: maria@example.com
done: true
cover: Attachments/projects/brand-guidelines.jpg
---

# Brand Guidelines

Updated brand identity system including logo, color palette, typography, and usage rules.
