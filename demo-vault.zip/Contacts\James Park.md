---
role: Senior Mobile Developer
company: Acme Corp
email: james@example.com
phone: "+1 555-0102"
department: Engineering
---
