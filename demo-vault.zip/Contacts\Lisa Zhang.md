---
role: Marketing Lead
company: Acme Corp
email: lisa@example.com
phone: "+1 555-0108"
department: Marketing
website: https://lisazhang.com
---
