---
status: Not started
priority: High
owner: Nina Patel
start_date: 2026-05-01
due_date: 2026-05-31
budget: 18000
progress: 0
tags:
  - devops
  - research
contact_email: nina@example.com
done: false
cover: Attachments/projects/security-audit.jpg
---

# Security Audit

Annual security audit covering infrastructure, application code, and access controls.
