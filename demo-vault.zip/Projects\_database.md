---
notion-bases: true
schema:
  - id: status
    name: Status
    type: status
    visible: true
    width: 140
    options:
      - value: Not started
        color: "#868686"
      - value: In progress
        color: "#4ea6f5"
      - value: Done
        color: "#4bb563"
      - value: Cancelled
        color: "#e25555"
  - id: priority
    name: Priority
    type: select
    visible: true
    width: 120
    options:
      - value: High
        color: "#e25555"
      - value: Medium
        color: "#e8a138"
      - value: Low
        color: "#4ea6f5"
  - id: owner
    name: Owner
    type: text
    visible: true
    width: 140
  - id: start_date
    name: Start date
    type: date
    visible: true
    width: 130
  - id: due_date
    name: Due date
    type: date
    visible: true
    width: 130
  - id: budget
    name: Budget
    type: number
    visible: true
    width: 120
    numberFormat:
      decimals: 2
      thousandsSeparator: true
      prefix: $
  - id: progress
    name: Progress
    type: number
    visible: true
    width: 100
    numberFormat:
      decimals: 0
      suffix: "%"
  - id: tags
    name: Tags
    type: multiselect
    visible: true
    width: 160
    options:
      - value: frontend
      - value: backend
      - value: design
      - value: devops
      - value: mobile
      - value: research
  - id: website
    name: Website
    type: url
    visible: true
    width: 180
  - id: contact_email
    name: Contact
    type: email
    visible: true
    width: 180
  - id: done
    name: Completed
    type: checkbox
    visible: true
    width: 100
  - id: days_left
    name: Days left
    type: formula
    visible: true
    width: 120
    formula: if(status = "Done", 0, if(due_date, round((number(due_date) - number(now())) / 86400000), 0))
  - id: cover
    name: Cover
    type: image
    visible: true
    width: 120
    imageSourceFolder: Attachments/projects
views:
  - id: default
    type: table
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    pinnedColumnId:
    includeSubfolders: false
  - id: board-view
    name: Board
    type: board
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    groupByColumnId: status
  - id: calendar-view
    name: Calendar
    type: calendar
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    calendarDateField: due_date
  - id: gallery-view
    name: Gallery
    type: gallery
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    galleryCardSize: medium
    galleryCoverField: cover
  - id: timeline-view
    name: Timeline
    type: timeline
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
    timelineStartField: start_date
    timelineEndField: due_date
    timelineZoom: weeks
  - id: list-view
    name: List
    type: list
    filters: []
    sorts: []
    hiddenColumns: []
    columnWidths: {}
---
