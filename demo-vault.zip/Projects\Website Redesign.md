---
status: In progress
priority: High
owner: Sarah Chen
start_date: 2026-02-01
due_date: 2026-04-15
budget: 45000
progress: 65
tags:
  - frontend
  - design
website: https://example.com
contact_email: sarah@example.com
done: false
cover: Attachments/projects/website-redesign.jpg
---

# Website Redesign

Complete overhaul of the company website with new branding, improved UX, and mobile-first approach.

## Goals
- Increase conversion rate by 20%
- Improve mobile experience
- Reduce page load time to under 2 seconds
